
function accept() {
    document.getElementById("popup").style.display = "none";
}

function reject() {
    history.back();
}
